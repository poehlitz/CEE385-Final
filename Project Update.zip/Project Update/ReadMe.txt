MAIN - Main File from which all functions are run to test. Printed version is in file. All figures generated and can be seen here for check.

All other printed pdfs - Printed pdf version of all functions. Title of tile is same as title of function.